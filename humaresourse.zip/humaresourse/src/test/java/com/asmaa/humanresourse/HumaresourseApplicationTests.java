package com.asmaa.humanresourse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HumaresourseApplicationTests {

	@Test
	void contextLoads() {
	}

}
