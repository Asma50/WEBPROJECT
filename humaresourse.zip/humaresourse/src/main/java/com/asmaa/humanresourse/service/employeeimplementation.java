package com.asmaa.humanresourse.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.asmaa.humanresourse.Repository.EmployeeRepository;
import com.asmaa.humanresourse.employee.Employee;
@Service
public class employeeimplementation implements employeeservice {
	@Autowired
	private EmployeeRepository repo;

	@Override
	public void saveemployeeservice(Employee Emp) {
		// TODO Auto-generated method stub
		this.repo.save(Emp);
		
	}

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public void deleteEmployeeById(long employeeid) {
		// TODO Auto-generated method stub
		this.repo.deleteById(employeeid);
		
	}

	

	

}

