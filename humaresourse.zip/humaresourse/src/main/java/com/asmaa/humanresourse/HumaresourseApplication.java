package com.asmaa.humanresourse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HumaresourseApplication {

	public static void main(String[] args) {
		SpringApplication.run(HumaresourseApplication.class, args);
	}

}
