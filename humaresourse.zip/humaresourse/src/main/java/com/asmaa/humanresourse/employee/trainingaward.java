package com.asmaa.humanresourse.employee;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="training")
public class trainingaward {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private Integer trainingid;
	private String training_name;
	private String award;
	public trainingaward(String training_name, String award) {
		super();
		this.training_name = training_name;
		this.award = award;
	}
	public trainingaward() {
		super();
	}
	public Integer getTrainingid() {
		return trainingid;
	}
	public void setTrainingid(Integer trainingid) {
		this.trainingid = trainingid;
	}
	public String getTraining_name() {
		return training_name;
	}
	public void setTraining_name(String training_name) {
		this.training_name = training_name;
	}
	public String getAward() {
		return award;
	}
	public void setAward(String award) {
		this.award = award;
	}
	
}
