package com.asmaa.humanresourse.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.asmaa.humanresourse.employee.Employee;
import com.asmaa.humanresourse.employee.trainingaward;

@Service

public interface awardservice {
	
	void savetrainingaward(trainingaward tra);
	List<trainingaward>getAlltraining();

}
