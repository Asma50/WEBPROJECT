package com.asmaa.humanresourse.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import com.asmaa.humanresourse.employee.leave;
import com.asmaa.humanresourse.service.LeaveService;

@Controller

public class Leavecontroller {
	@Autowired private LeaveService service;
	
	@GetMapping("/leavee")
	public String employee() {
		return "registerleaveog";
	}
	

	@GetMapping("/viewleaveog")
	public String ViewLeave(Model model) {
		model.addAttribute("live", service.getAllleave());
		return "viewleaveog";
	}

	@GetMapping("/leave")
	public String adduser(Model model) {
		leave Leave = new leave();
		model.addAttribute("leav", Leave);
		return "registerleaveog";
	}
	@GetMapping("/lea")
	public String AddEmployee(@ModelAttribute("leav") leave lv) {
		service.saveLeave(lv);
		return "redirect:/dash";
	}
	
}
