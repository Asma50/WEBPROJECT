package com.asmaa.humanresourse.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.asmaa.humanresourse.Repository.LeaveRepository;
import com.asmaa.humanresourse.employee.Employee;
import com.asmaa.humanresourse.employee.leave;

@Service
public class LeaveImple implements LeaveService {
	@Autowired
	private LeaveRepository repo;

	@Override
	public void saveLeave(leave lf) {
		// TODO Auto-generated method stub
		this.repo.save(lf);
		
	}
	
	@Override
	public List<leave> getAllleave() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

}
