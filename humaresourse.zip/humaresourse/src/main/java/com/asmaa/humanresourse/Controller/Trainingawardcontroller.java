package com.asmaa.humanresourse.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import com.asmaa.humanresourse.employee.trainingaward;
import com.asmaa.humanresourse.service.awardservice;
@Controller

public class Trainingawardcontroller {
	@Autowired
	private  awardservice service;
	
	@GetMapping("/trainss")
	public String ViewTraining(Model model) {
		model.addAttribute("tr", service.getAlltraining());
		return "training";
	}
	
	
	@GetMapping("/trains")
	public String Award(Model model) {
		trainingaward Tr = new trainingaward();
		model.addAttribute("Tr", Tr);
		return "regleave";
	}
	@GetMapping("/mm")
	public String AWARD(@ModelAttribute("Tr")trainingaward Tr) {
		service.savetrainingaward(Tr);
		return "redirect:/dash";
	}
	
	@GetMapping("/training")
	public String training() {
		return "regleave";
	}
	
	
}
