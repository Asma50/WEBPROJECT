package com.asmaa.humanresourse.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.asmaa.humanresourse.employee.leave;

@Service
public interface LeaveService {
	void saveLeave(leave lf);
	List<leave>getAllleave();

}
