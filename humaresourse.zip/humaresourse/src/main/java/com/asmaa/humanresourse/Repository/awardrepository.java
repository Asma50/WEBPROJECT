package com.asmaa.humanresourse.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.asmaa.humanresourse.employee.trainingaward;

@Repository

public interface awardrepository  extends JpaRepository<trainingaward, Integer>{

}
