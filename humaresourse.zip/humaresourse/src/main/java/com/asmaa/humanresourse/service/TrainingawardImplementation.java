package com.asmaa.humanresourse.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.asmaa.humanresourse.Repository.awardrepository;
import com.asmaa.humanresourse.employee.Employee;
import com.asmaa.humanresourse.employee.trainingaward;
@Service
public class TrainingawardImplementation implements awardservice  {
	@Autowired
	private  awardrepository  trai;

	@Override
	public void savetrainingaward(trainingaward tra) {
		// TODO Auto-generated method stub
		this.trai.save(tra);
		
	}
	@Override
	public List<trainingaward> getAlltraining() {
		// TODO Auto-generated method stub
		return trai.findAll();
	}


}
