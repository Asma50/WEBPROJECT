package com.asmaa.humanresourse.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;

import com.asmaa.humanresourse.employee.Employee;
import com.asmaa.humanresourse.service.employeeservice;

@org.springframework.stereotype.Controller

public class Controller {
	@Autowired
	private  employeeservice service;
	
	@GetMapping("/")
	public String employee() {
		return "registeremployee";
	}
	@GetMapping("/asmaa")
	public String adduser(Model model) {
		Employee employee = new Employee();
		model.addAttribute("employee", employee);
		return "registeremployee";
	}
	@GetMapping("/employee")
	public String AddEmployee(@ModelAttribute("employee") Employee emp) {
		service.saveemployeeservice(emp);
		return "redirect:/dash";
		
	}
	@GetMapping("/viewemployee")
	public String ViewEmployee(Model model) {
		model.addAttribute("emp", service.getAllEmployee());
		return "viewemployee";
	}
	@GetMapping("/daleteemployee/{employeeid}")
	public String Employee(@PathVariable(value="employeeid")long employeeid) {
		this.service.deleteEmployeeById(employeeid);
		return "redirect:/vemployee";
		
	}

	
	

}
