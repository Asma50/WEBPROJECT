package com.asmaa.humanresourse.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.asmaa.humanresourse.employee.Employee;
@Service
public interface employeeservice {
	void saveemployeeservice(Employee Emp);
	List<Employee>getAllEmployee();
	void deleteEmployeeById(long employeeid);

}
