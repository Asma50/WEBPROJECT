package com.asmaa.humanresourse.employee;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="leve")

public class leave {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer leaveid;
	private String leave_name;
	private String starting_date;
	private String end_date;
	public leave(String leave_name, String starting_date, String end_date) {
		super();
		this.leave_name = leave_name;
		this.starting_date = starting_date;
		this.end_date = end_date;
	}
	public leave() {
		super();
	}
	public Integer getLeaveid() {
		return leaveid;
	}
	public void setLeaveid(Integer leaveid) {
		this.leaveid = leaveid;
	}
	public String getLeave_name() {
		return leave_name;
	}
	public void setLeave_name(String leave_name) {
		this.leave_name = leave_name;
	}
	public String getStarting_date() {
		return starting_date;
	}
	public void setStarting_date(String starting_date) {
		this.starting_date = starting_date;
	}
	public String getEnd_date() {
		return end_date;
	}
	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	
	
}
