package com.asmaa.humanresourse.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.asmaa.humanresourse.service.employeeservice;

@Controller

public class Viewemployeecontroller {
	@Autowired private employeeservice service;
	
	@GetMapping("/vemployee")
	public String employee() {
		return "viewemployee";
	}
	
}
